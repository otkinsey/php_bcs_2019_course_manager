<?php require('config.php'); ?>
<?php $db = new Database('otkinsey','komet1','mysql:host=localhost;dbname=module_5'); ?>
<!DOCTYPE html>
<html>
<!-- the head section -->
<head>
    <title>Course Manager</title>
    <link rel="stylesheet" href="styles/styles.css"></link>
    <!-- Compressed CSS -->
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/foundation-sites@6.5.3/dist/css/foundation.min.css" integrity="sha256-xpOKVlYXzQ3P03j397+jWFZLMBXLES3IiryeClgU5og= sha384-gP4DhqyoT9b1vaikoHi9XQ8If7UNLO73JFOOlQV1RATrA7D0O7TjJZifac6NwPps sha512-AKwIib1E+xDeXe0tCgbc9uSvPwVYl6Awj7xl0FoaPFostZHOuDQ1abnDNCYtxL/HWEnVOMrFyf91TDgLPi9pNg==" crossorigin="anonymous">
    <!-- Compressed JavaScript -->
    <script src="https://cdn.jsdelivr.net/npm/foundation-sites@6.5.3/dist/js/foundation.min.js" integrity="sha256-/PFxCnsMh+nTuM0k3VJCRch1gwnCfKjaP8rJNq5SoBg= sha384-9ksAFjQjZnpqt6VtpjMjlp2S0qrGbcwF/rvrLUg2vciMhwc1UJJeAAOLuJ96w+Nj sha512-UMSn6RHqqJeJcIfV1eS2tPKCjzaHkU/KqgAnQ7Nzn0mLicFxaVhm9vq7zG5+0LALt15j1ljlg8Fp9PT1VGNmDw==" crossorigin="anonymous"></script>
    <link rel="stylesheet" type="text/css"
          href="/cs602/CS602_Module5Samples/part2_pdo/Murach2/ch05_guitar_shop_mvc/main.css">
</head>

<!-- the body section -->
<body>
    <div class="grid-container">
<header>
    <h1>
        <a href="index.php">Course Manager</a>
    </h1>
    <hr>
</header>


