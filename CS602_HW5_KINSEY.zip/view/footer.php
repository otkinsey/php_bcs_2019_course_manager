<hr>
<footer>
    <p class="copyright">
        &copy; <?php echo date("Y"); ?> Course Manager
    </p>
</footer>
</div>
</body>
</html>